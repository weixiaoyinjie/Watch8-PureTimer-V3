package com.watch8.contractpulse;

import android.app.Activity;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.content.Context;
import android.widget.Toast;

/** Two launcher icons that each toggle their loop without opening the main UI. */
public abstract class ToggleShortcutActivity extends Activity {
    protected abstract int timerId();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        runToggle();
    }

    @Override protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        runToggle();
    }

    private void runToggle() {
        TimerEngine engine = new TimerEngine(this);
        int id = timerId();
        engine.toggle(id);
        boolean active = engine.running(id);
        Toast.makeText(this, TimerEngine.title(id) + (active ? " 已启动" : " 已停止"),
                Toast.LENGTH_SHORT).show();
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(VibrationEffect.createOneShot(55, VibrationEffect.DEFAULT_AMPLITUDE));
        }
        finish();
    }
}
