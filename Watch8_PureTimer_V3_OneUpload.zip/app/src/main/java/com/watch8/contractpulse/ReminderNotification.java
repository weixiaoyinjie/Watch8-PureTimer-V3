package com.watch8.contractpulse;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;

/** Notification is optional; sound and vibration are triggered independently on every due alarm. */
public final class ReminderNotification {
    private static final String CHANNEL = "pure_timer_notice_v3";
    private ReminderNotification() {}

    public static void channels(Context ctx) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL, "纯计时 · 到点提醒", NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("手表到点显示通知。提示音和振动由应用独立触发，可在应用设置页开关。");
        channel.setSound(null, null); // Avoid double ringing: own alert player always plays the sound.
        channel.enableVibration(false); // Avoid double vibration: direct watch vibration below.
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(channel);
    }

    public static boolean permission(Context ctx) {
        return Build.VERSION.SDK_INT < 33 ||
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        == PackageManager.PERMISSION_GRANTED;
    }

    public static void alert(Context ctx, TimerEngine engine, int id) {
        if (engine.vibrate()) buzz(ctx, engine.vibrationStrength());
        channels(ctx);
        if (!permission(ctx)) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Intent open = new Intent(ctx, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(ctx, 4800 + id, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification note = new Notification.Builder(ctx, CHANNEL)
                .setSmallIcon(R.drawable.ic_watch)
                .setContentTitle(TimerEngine.title(id) + " · 时间到")
                .setContentText("时间到！点击打开六键计时器")
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_HIGH)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(content)
                .setAutoCancel(true)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true)
                .build();
        nm.notify(4400 + id, note);
    }

    public static void buzz(Context context, int strength) {
        Vibrator v = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        if (v == null || !v.hasVibrator()) return;
        long[] pattern;
        if (strength == 0) pattern = new long[] { 0, 130, 100, 130 };
        else if (strength == 2) pattern = new long[] { 0, 270, 90, 270, 90, 320 };
        else pattern = new long[] { 0, 200, 100, 200, 100, 200 };
        try { v.vibrate(VibrationEffect.createWaveform(pattern, -1)); }
        catch (RuntimeException ignored) { /* OS haptic or DND policy may suppress it. */ }
    }
}
