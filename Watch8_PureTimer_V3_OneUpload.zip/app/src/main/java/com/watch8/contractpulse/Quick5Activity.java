package com.watch8.contractpulse;

public final class Quick5Activity extends ToggleShortcutActivity {
    @Override protected int timerId() { return TimerEngine.LOOP_5; }
}
