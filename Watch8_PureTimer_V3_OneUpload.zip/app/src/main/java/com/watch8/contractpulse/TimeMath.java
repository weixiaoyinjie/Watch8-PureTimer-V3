package com.watch8.contractpulse;

/** Relative countdown time math, with missed cycles skipped rather than burst-replayed. */
public final class TimeMath {
    private TimeMath() {}

    public static long nextDue(long now, long length) {
        if (length <= 0) throw new IllegalArgumentException("length must be >0");
        return now + length;
    }

    public static long nextAfterMissed(long oldDue, long now, long duration) {
        if (duration <= 0) throw new IllegalArgumentException("duration must be >0");
        if (oldDue > now) return oldDue;
        return oldDue + ((now - oldDue) / duration + 1) * duration;
    }
}
