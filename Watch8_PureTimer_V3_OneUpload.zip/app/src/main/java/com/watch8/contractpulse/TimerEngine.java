package com.watch8.contractpulse;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

/** Six independent, persisted offline alarms. No polling and no screen wake-up. */
public final class TimerEngine {
    // Keep the first three IDs compatible with previous ContractPulse timer state.
    public static final int LOOP_5 = 0;
    public static final int ONCE_5 = 1;
    public static final int ONCE_15 = 2;
    public static final int LOOP_15 = 3;
    public static final int ONCE_CUSTOM = 4;
    public static final int LOOP_CUSTOM = 5;
    public static final int COUNT = 6;
    public static final int[] DISPLAY_ORDER = {
            ONCE_5, LOOP_5, ONCE_15, LOOP_15, ONCE_CUSTOM, LOOP_CUSTOM
    };
    public static final String EXTRA_ID = "timer_id";
    public static final String EXTRA_DUE = "timer_due";
    public static final String EXTRA_GEN = "timer_generation";
    private static final long MINUTE = 60_000L;
    private static final String PREFS = "puretimer_v3";

    private final Context context;
    private final AlarmManager alarmManager;
    private final SharedPreferences prefs;

    public TimerEngine(Context source) {
        context = source.getApplicationContext();
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
    }

    public static boolean valid(int id) { return id >= 0 && id < COUNT; }
    public static boolean loop(int id) {
        return id == LOOP_5 || id == LOOP_15 || id == LOOP_CUSTOM;
    }
    public static boolean custom(int id) { return id == ONCE_CUSTOM || id == LOOP_CUSTOM; }

    public static String title(int id) {
        switch (id) {
            case LOOP_5: return "5分钟循环";
            case ONCE_5: return "5分钟单次";
            case ONCE_15: return "15分钟单次";
            case LOOP_15: return "15分钟循环";
            case ONCE_CUSTOM: return "自定义单次";
            case LOOP_CUSTOM: return "自定义循环";
            default: return "定时提醒";
        }
    }

    private static String key(int id, String field) { return "timer_" + id + "_" + field; }
    public boolean running(int id) { return valid(id) && prefs.getBoolean(key(id, "running"), false); }
    public long due(int id) { return valid(id) ? prefs.getLong(key(id, "due"), 0L) : 0L; }
    public boolean anyRunning() {
        for (int id = 0; id < COUNT; id++) if (running(id)) return true;
        return false;
    }
    public boolean vibrate() { return prefs.getBoolean("vibrate", true); }
    public boolean sound() { return prefs.getBoolean("sound", true); }
    public int vibrationStrength() { return prefs.getInt("strength", 1); }
    public void setOption(String name, boolean value) {
        if ("sound".equals(name) || "vibrate".equals(name)) {
            prefs.edit().putBoolean(name, value).apply();
        }
    }
    public void cycleStrength() { prefs.edit().putInt("strength", (vibrationStrength() + 1) % 3).apply(); }

    /** Zero means that user input is required before first launch. */
    public int customMinutes(int id) {
        if (!custom(id)) return 0;
        return prefs.getInt(key(id, "minutes"), 0);
    }
    public void setCustomMinutes(int id, int minutes) {
        if (!custom(id) || minutes < 1 || minutes > 999) {
            throw new IllegalArgumentException("custom minutes must be 1..999");
        }
        prefs.edit().putInt(key(id, "minutes"), minutes).commit();
    }

    public long length(int id) {
        if (id == LOOP_5 || id == ONCE_5) return 5 * MINUTE;
        if (id == LOOP_15 || id == ONCE_15) return 15 * MINUTE;
        if (custom(id)) return customMinutes(id) * MINUTE;
        return 0L;
    }

    public boolean exactAllowed() {
        return Build.VERSION.SDK_INT < 31 || alarmManager.canScheduleExactAlarms();
    }

    public synchronized void toggle(int id) {
        if (!valid(id)) return;
        if (running(id)) stop(id);
        else start(id);
    }

    public synchronized boolean start(int id) {
        if (!valid(id) || length(id) <= 0) return false;
        cancel(id);
        int gen = prefs.getInt(key(id, "gen"), 0) + 1;
        long at = TimeMath.nextDue(System.currentTimeMillis(), length(id));
        prefs.edit().putInt(key(id, "gen"), gen)
                .putBoolean(key(id, "running"), true)
                .putLong(key(id, "due"), at).commit();
        schedule(id);
        return true;
    }

    public synchronized void stop(int id) {
        if (!valid(id)) return;
        cancel(id);
        int gen = prefs.getInt(key(id, "gen"), 0) + 1;
        prefs.edit().putInt(key(id, "gen"), gen)
                .putBoolean(key(id, "running"), false)
                .putLong(key(id, "due"), 0L).commit();
    }

    public synchronized void stopAll() {
        for (int id = 0; id < COUNT; id++) stop(id);
    }

    private PendingIntent alarmIntent(int id, int gen, long at) {
        Intent intent = new Intent(context, TimerReceiver.class);
        intent.setAction("com.watch8.contractpulse.TIMER_" + id);
        intent.putExtra(EXTRA_ID, id);
        intent.putExtra(EXTRA_DUE, at);
        intent.putExtra(EXTRA_GEN, gen);
        return PendingIntent.getBroadcast(context, 3800 + id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private void cancel(int id) {
        PendingIntent pi = alarmIntent(id, 0, 0);
        alarmManager.cancel(pi);
        pi.cancel();
    }

    private void schedule(int id) {
        if (!running(id)) return;
        long target = Math.max(System.currentTimeMillis() + 1000L, due(id));
        PendingIntent pi = alarmIntent(id, prefs.getInt(key(id, "gen"), 0), due(id));
        if (exactAllowed()) {
            try {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target, pi);
                return;
            } catch (SecurityException ignored) { /* Permission revoked while scheduling. */ }
        }
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target, pi);
    }

    /** Restore after reboot, app update, permission grant, time change, or app resume. */
    public synchronized void rescheduleAll(boolean recovery) {
        long now = System.currentTimeMillis();
        for (int id = 0; id < COUNT; id++) {
            cancel(id);
            if (!running(id)) continue;
            long at = due(id);
            if (recovery && at <= now) {
                if (loop(id) && length(id) > 0) {
                    prefs.edit().putLong(key(id, "due"),
                            TimeMath.nextAfterMissed(at, now, length(id))).commit();
                } else {
                    prefs.edit().putBoolean(key(id, "running"), false)
                            .putLong(key(id, "due"), 0L).commit();
                    continue;
                }
            }
            schedule(id);
        }
    }

    /** Returns true for the unique, current due alarm; advances loops before alerting. */
    public synchronized boolean onFire(int id, long at, int gen) {
        if (!valid(id) || !running(id)) return false;
        if (prefs.getInt(key(id, "gen"), 0) != gen || due(id) != at) return false;
        long now = System.currentTimeMillis();
        if (now + 2000L < at) { schedule(id); return false; }
        if (loop(id) && length(id) > 0) {
            prefs.edit().putLong(key(id, "due"),
                    TimeMath.nextAfterMissed(at, now, length(id))).commit();
            cancel(id);
            schedule(id);
        } else {
            prefs.edit().putBoolean(key(id, "running"), false)
                    .putLong(key(id, "due"), 0L).commit();
            cancel(id);
        }
        return true;
    }
}
