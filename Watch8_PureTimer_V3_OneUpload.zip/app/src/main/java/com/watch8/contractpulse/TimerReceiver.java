package com.watch8.contractpulse;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class TimerReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        int id = intent.getIntExtra(TimerEngine.EXTRA_ID, -1);
        long due = intent.getLongExtra(TimerEngine.EXTRA_DUE, -1L);
        int generation = intent.getIntExtra(TimerEngine.EXTRA_GEN, -1);
        TimerEngine engine = new TimerEngine(context);
        if (engine.onFire(id, due, generation)) {
            ReminderNotification.alert(context, engine, id);
            if (engine.sound()) AlertPlayer.play(context, goAsync());
        }
    }
}
